#include "calculator.h"


int Calculator::add(int a, int b)
{
    return a + b;
}

int Calculator::sub(int a, int b)
{
    return a - b;
}

int Calculator::mul(int a, int b)
{
    return a * b;
}


int Calculator::div(int a, int b)
{
    return a / b;
}
