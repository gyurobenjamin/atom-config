Sublime Text Integration
========================

The detailed information and steps are described in the main documentation:
`PlatformIO integration with Sublime Text <http://docs.platformio.org/en/stable/ide/sublimetext.html>`_.

.. image:: http://docs.platformio.org/en/stable/_images/ide-sublime-text-platformio-newproject-5.png
    :target: http://docs.platformio.org/en/stable/ide/sublimetext.html
